<?php
    return array(
        'host' => 'localhost',
        'dbname' => 'tproba',
        'charset' => 'utf8',
        'user' => 'root',
        'password' => ''
    );
?>